const title = document.querySelector('.title h2')
const result = document.querySelector('.result')
