const result = document.querySelector('.result')
